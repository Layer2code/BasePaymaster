module.exports = {
  configureYulOptimizer: true
}
